class ExemploEscrever4 {
    public static void main(String args[]) {
        System.out.println("Inteiro: " + 13);
        System.out.println("Real: " + 13.45);
    }
}