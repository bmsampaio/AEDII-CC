class ExemploEscrever5 {
    public static void main(String args[]) {
        int n;
        n = 2 + 3;
        System.out.println("Inteiro: " + n);
    }
}