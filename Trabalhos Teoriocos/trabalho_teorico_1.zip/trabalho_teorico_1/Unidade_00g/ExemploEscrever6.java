// Exemplo de como somar dois números
class ExemploEscrever6 {
    public static void main(String args[]) {
        double x, y; // números reais de dupla precisão
        x = 2;
        y = 3.0;
        /* iniciando o y, e fazendo y = y+x; */ y = y + x;
        System.out.println("Valor x+y:" + (x + y));
    } // fim do método principal
} /* fim da classe */